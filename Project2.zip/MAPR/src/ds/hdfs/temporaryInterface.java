package ds.hdfs;

public interface temporaryInterface extends java.rmi.Remote {

}
