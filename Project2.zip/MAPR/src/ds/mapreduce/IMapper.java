package ds.mapreduce;

public interface IMapper {
	public String map(String inp,String expr);
}
