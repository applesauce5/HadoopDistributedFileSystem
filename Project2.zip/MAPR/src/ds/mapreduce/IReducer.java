package ds.mapreduce;

public interface IReducer {
	public String reduce(String inp);
}
