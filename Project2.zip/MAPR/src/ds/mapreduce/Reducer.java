package ds.mapreduce;

public class Reducer implements IReducer{

	public String reduce(String inpdata)
	{
		return "";
	}
}
